# Why your successful run added no NEW messages

## Evidence from the supplied old-code log
Run: 2026-11-10 06:29 UTC (11:29 Pakistan time).
Repository: vfxscottwilson-gif/Insta-outreach.
Commit: 2f47c19bc02da8251deae47cdb2f72728c42a63a.
Mode: full preparation, NOT sync-only. The expanded shell condition has schedule="" and sync_only="false", so the else branch ran python main.py.

Exact result:
    synced=0, followups=0, new=0, requeued=11, private=0, review=0, no_handle=1, ai_notes=0

This means:
- ZERO new initial messages were created.
- ELEVEN existing unsent drafts were selected from Outreach Log and appended to Today Queue by the normal successful code path.
- ZERO sends were newly confirmed. GitHub does not send messages itself.
- ONE nonblank source row had no valid Instagram handle and was skipped.
- No reported AI failure, rejected draft or private-profile skip occurred in this run.

Your screenshot shows Outreach Log selected. Requeueing does not add another Outreach Log row or rewrite Message Sent. It adds rows to Today Queue. Your visible Outreach Log contains 11 leads, which is consistent with reusing those drafts, although the screenshot does not show their Stage values. Open Today Queue in the same spreadsheet; the full run should have appended those 11 drafts there. The old code trusts API responses, so the log is not independent read-back proof of all writes.

## Why new=0
The old code checks whether each source handle already exists anywhere in Outreach Log. If it does, it skips it regardless of whether the source lead has been edited. It schedules due follow-ups and requeues old drafts BEFORE considering new leads; those consume available account slots.

The supplied log does not include the source inventory, account caps, pauses, warmup ages or queue reservation counts. Consequently it cannot distinguish:
1. All valid source handles were already known; or
2. Unseen source handles existed but no account capacity remained after reservations/requeues; or a combination.

A successful exit means the program completed its rules without an exception. It does not mean it created new messages. This particular run is not evidence of an AI/model-name crash. Missing IG_ACCESS_TOKEN/IG_USER_ID is supported optional behavior here, not the cause of this successful requeue run. Node deprecation warnings did not prevent execution either.

This app also does not discover new prospects or phone numbers on its own. It reads supplied rows from the source tab (configured as Insta Id's in your log), and copies Phone if present there. To grow Outreach Log you need genuinely new valid source handles, usable niche/bio, account slots and working generation. Existing drafts remain existing drafts; fabricating duplicates would not solve this.

## What this revision fixes
- Explicit full versus sync-only mode in output.
- Source tab name/id, source row count, valid unique leads, already-known leads and unseen leads.
- Source duplicate count and row numbers of invalid handles (first 30), including the cause represented by no_handle=1.
- Per-account available slots after existing queue reservations, plus total capacity after backlog scheduling.
- A plain-English no-new reason and GitHub warning when full preparation creates no new messages.
- A GitHub Actions job summary with a direct link to Today Queue in the configured sheet.
- Read-back verification of newly appended log and queue rows; missing expected rows fail the job.
- Existing deduplication, account caps and human sending are preserved. Legitimate no-work runs are warnings; actual write/read/generation failures fail.

Use the revised ZIP instead of the earlier one. Upload the contents of app/ to the same GitHub repository root, including .github/workflows/outreach.yml. Run full preparation once and inspect the Actions job Summary. It will now tell you whether to add source leads, correct invalid handle rows, inspect Accounts phases/caps or inspect review/API errors.

The code revision is prepared locally; the live repository and spreadsheet were not modified. Historical sheet data is not repaired. If Today Queue is also empty for the logged date, check the exact Sheet ID, filters/hidden rows and any later edits; the supplied old log alone cannot prove where those rows went.

## Verification
14 offline regression checks passed using import stubs for unavailable external libraries. A mocked pipeline regression reproduces 11 requeues / 0 new, verifies 11 queue rows and confirms AI is not called; it is a demonstration of that code path, not proof that your live source contained only known leads. Read-back tests also prove missing rows trigger an error. Python syntax compilation passed. Live Google/GitHub/API verification has not been performed.
