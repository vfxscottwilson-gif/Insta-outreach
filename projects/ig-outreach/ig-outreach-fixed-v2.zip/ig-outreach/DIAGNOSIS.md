> Updated after receiving an actual run log: read RUN-LOG-DIAGNOSIS.md first. That run completed with 11 requeues and zero new drafts; it did not show an AI crash. Earlier conditional code findings below are not the cause established by that run.

# Diagnosis and corrected package

## Scope and evidence
Reviewed the supplied four Markdown files, Python source, Apps Script, local launcher and GitHub Actions YAML. The Markdown files describe intended behavior; they are not evidence of a successful live run. The original folder is untouched. This package is a corrected copy, not a deployment.

No actual Google Sheet, traceback, Run Log export, failed Actions URL, credentials or configured Git remote were available. Therefore the findings below are reproducible code defects and conditional failure paths, NOT a claim that one particular defect caused your observed incident. Nothing here establishes that Google Sheets itself is crashing.

## What the workflow does
1. Opens a Google Sheet using a service account; creates/extends Outreach Log, Today Queue, Accounts and Run Log.
2. Copies manually marked sent rows from Today Queue into the log, calculates next follow-up dates, and expires skipped older queue rows.
3. Calculates per-account capacity (account age, pause, daily cap and existing queue rows).
4. Drafts due follow-ups, requeues unsent drafts and reads source leads.
5. Optionally reads public business/creator Instagram profiles; falls back to sheet niche/bio when available.
6. Generates AI drafts, validates word count, spam phrases, links, free-sample mention and repeated opening words, then schedules drafts across accounts.
7. A human sends the message. GitHub never sends Instagram DMs. The local send_assist helper opens Chrome and copies text.

Default follow-up intervals are 4,4,4 days AFTER the preceding actual send (approximately days 4,8,12 only if you send each on time). Main run: 12:00 UTC (17:00 Pakistan). Sync: 00:00,04:00,08:00,16:00,20:00 UTC; full run already syncs at noon.

## Model-name question
Yes, each generation request needs an actual model ID. You do not necessarily need to type it: the original code lists models and chooses one. An API key authenticates your account; it does not guarantee access to every listed model, quota, balance, chat endpoint compatibility or output.

Original AI.__init__ rejects every key whose model-list request fails, even if generation with a known model would work. Discovery can also filter out good models or select inaccessible/non-chat models. This explains how adding a valid explicit model can fix a discovery failure without fixing a bad key or exhausted quota.

The corrected code supports optional AI_MODELS (JSON mapping provider -> list of model IDs). Configured IDs bypass discovery for that provider. Without AI_MODELS it still discovers models. Use current IDs from your provider; no model ID is promised to remain available.

GitHub variable example (replace the placeholder):
    AI_MODELS = {"groq": ["YOUR_CURRENT_CHAT_MODEL_ID"]}

AI_API_KEYS secret example syntax (one entry per line; never put actual keys in documentation):
    groq:YOUR_KEY
    gemini:YOUR_KEY
    mistral:YOUR_KEY

Recognized key prefixes still work without provider labels. Opaque keys must use provider:key; the fix no longer sends unknown keys to several unrelated providers to guess their origin. One usable provider is sufficient; two are useful for fallback, not a technical requirement. OpenRouter explicit IDs must be chosen with care: selecting a paid ID can incur provider charges, whereas automatic OpenRouter discovery filters for zero-priced models.

## Findings and changes

| Finding in original | Failure or misleading behavior | Package change |
|---|---|---|
| AI initialized before checking whether generation is needed | A model-list failure stops even requeue work that already has drafts | Lazy AI initialization; existing drafts can requeue without an AI key |
| Model list is mandatory | Valid generation access cannot help when discovery fails | Optional explicit AI_MODELS, passed through Actions |
| Generic SKIP regex contains `instruct` | Excludes legitimate instruction-tuned chat models | Removed this exclusion |
| Gemini discovery accepts only names containing `flash` | Rejects other generateContent-capable models | Uses supported generation method plus exclusion filter |
| OpenRouter free-price comparison is string-equality to `0` | `0.0`/`0.0000` incorrectly rejected | Numeric zero comparison |
| First 403 disables a whole provider key | One model permission issue prevents trying other models | Only 401 disables authentication; 403 removes that model and tries another |
| Unsupported models retried repeatedly | More latency and failure loops | Removes models on 400/403/404/410; skips unnecessary final wait |
| HTTP error text copied to logs | Exception URLs can disclose sensitive request details | AI errors log exception type/status rather than URLs |
| AI/read-leads exceptions caught then normal return | GitHub shows green even when preparation failed | Checkpoint prepared rows, then return nonzero for these failures |
| Accounts read/written by fixed column number | Reordered columns can corrupt phases, ignore pauses or misread caps | Maps Accounts by header; rejects duplicate accounts |
| Manual account override applied before age check | New account can bypass warmup | Age ramp enforced before override; override can only reduce mature configured cap |
| Duplicate sheet headers collapse in a dictionary | Reads/writes the wrong column | Duplicate nonblank headers rejected with explanation |
| `int(t[-1])` on arbitrary queue Type | ValueError/IndexError or wrong follow-up updates | Accepts only Message and Follow-up 1/2/3; invalid rows stay unsynced |
| Unmatched queue lead still marked Synced | Sent record silently lost | Leaves unmatched row unsynced with a console warning |
| Sync overwrites terminal Lead Status with Contacted | Can erase Do not contact / Client / Not interested status | Preserves terminal statuses |
| Source defaults to first sheet without validation | If a generated tab is first, wrong data may be read | Generated tabs rejected as lead sources; set LEADS_TAB explicitly |
| Two schedules both include noon | Redundant queued run at noon | Sync schedule excludes noon |
| Apps Script uses script timezone and overwrites timestamps | Wrong send date near midnight; repeating Yes changes recorded time | Spreadsheet timezone; preserve existing stamps; same affirmative values as Python |
| Launcher picks first secrets JSON file | Can choose profiles.json as Google credentials | Selects JSON with type=service_account |
| Invalid send-window hour/order | datetime ValueError with poor explanation | Validates hours, minutes and same-day increasing window |

## Configuration/environment failures code cannot cure
- Missing or malformed GOOGLE_SERVICE_ACCOUNT_JSON; invalid file path on GitHub (use JSON content as its secret).
- Missing SHEET_ID, wrong sheet ID, Sheets API disabled, or Sheet not shared as Editor with the service account client_email.
- GitHub vars versus secrets mismatch. This workflow reads SHEET_ID and OFFER from VARIABLES; AI_API_KEYS and GOOGLE_SERVICE_ACCOUNT_JSON from SECRETS. Same name in the wrong category resolves to empty.
- Invalid TIMEZONE, nonnumeric DAILY_LIMIT_PER_ACCOUNT or bad settings cause startup errors. Use an IANA zone such as Asia/Karachi and an integer cap.
- 429 quota/rate limits, insufficient credit, expired/revoked API keys, removed models, unsupported request parameters, unavailable providers or network outages. Model listing is not an end-to-end generation test.
- No active accounts, account still under 14 days old, paused accounts, caps consumed by today's queue, or no eligible leads legitimately produce no new messages.
- Instagram private/personal profiles cannot be read through Business Discovery; an API lookup failure is not proof that an account is private. Add accurate source niche/bio.
- GitHub job timeout (45 minutes): multiple keys x models x 45-second requests and repeated validation can consume the budget. A workflow timeout can interrupt sheet writes. This package reduces several wasteful paths; it does not guarantee completion for arbitrary lead volumes.
- Scheduled runs depend on GitHub scheduling and repository configuration; verify the workflow is enabled on the default branch.

## Known remaining limits / recovery
- Sheets writes across tabs are not transactional. A lost append response followed by retry can duplicate rows. Do not run local full preparation and GitHub preparation concurrently; Actions concurrency only covers Actions jobs. A durable ID/transaction design is a larger change and is not claimed fixed here.
- Sync identifies a log row by handle, and old duplicate handles may bind to the first row. Do not delete log history; reconcile duplicates carefully with a backup.
- Rows already marked Needs review or Private are considered known. Merely fixing their source bio will not automatically retry them. Review their log draft/context manually; for a suitable manually approved draft set Stage=Queued so it can requeue, retaining the existing row.
- Follow-up generation still has precedence over new leads. A provider outage can produce a partial run; prepared rows are saved where possible and Actions now fails visibly.
- If a send timestamp is missing, sync still uses current time. Install the updated Apps Script and align BOTH spreadsheet timezone and TIMEZONE. Existing wrong timestamps are not automatically repaired. Removing Yes does not clear a preserved stamp; correct erroneous stamps manually.
- Repeated opener checks across all historical messages can become overly restrictive as history grows; rejected drafts require review. Validators do not prove factual accuracy.
- Suggested times can extend beyond the send window and are labeled late. Repeated preparation runs do not account for existing per-account message spacing. Review late rows before sending.
- Start-up failures before connect completes cannot be recorded in the sheet Run Log; read the Actions console traceback.
- Dependencies retain original lower-bound requirements. Future dependency changes may require retesting; this package does not claim a fully locked build.

## Apply to GitHub without changing the folder structure
1. Back up your Sheet and repository first. Keep your real secrets separately.
2. This ZIP retains the outer project and app/ layout. The original docs say app/ is the Git repository root. Upload the CONTENTS of app/ (including hidden .github/) to that same repository root. Uploading the whole outer folder into a repository that expects main.py at its root will break Actions paths.
3. Preserve existing GitHub secrets/variables. Set LEADS_TAB to the actual source tab. Optionally set AI_MODELS as above, using a model your key can access.
4. Replace the bound Sheet Apps Script with app/apps_script.gs. Set the spreadsheet timezone to match TIMEZONE.
5. Run the manual workflow with sync_only=true first. This IS a write operation: it updates log state, expires stale queue rows and may create tabs/headers. Earlier docs calling this a read-only safe test were inaccurate.
6. Then run full preparation with one account and 3-10 leads. Check Actions logs, Run Log, queue contents, account caps and model output before sending.
7. This package was not uploaded, committed, deployed or run against your accounts. Historical sheet data has not been repaired.

## References for API behavior
- Gemini model discovery and supported generation methods: https://ai.google.dev/api/models
- OpenRouter free-model router and model selection: https://openrouter.ai/collections/free-models

See VALIDATION.txt for the actual local check results.
