"""Run pure-logic regression tests when third-party packages cannot be installed.
Stubs only supply imports/types/A1 conversion; network operations are forbidden.
"""
import sys,types,unittest
from pathlib import Path
sys.path.insert(0,str((Path(__file__).resolve().parent/'app')))
g=types.ModuleType('gspread'); u=types.ModuleType('gspread.utils')
def a1(row,col):
 text=''
 while col:
  col,rem=divmod(col-1,26); text=chr(65+rem)+text
 return f'{text}{row}'
u.rowcol_to_a1=a1
g.exceptions=types.SimpleNamespace(APIError=type('APIError',(Exception,),{}))
g.WorksheetNotFound=type('WorksheetNotFound',(Exception,),{})
sys.modules['gspread']=g;sys.modules['gspread.utils']=u
req=types.ModuleType('requests')
class HTTPError(Exception):
 def __init__(self,message='',response=None):
  super().__init__(message);self.response=response
req.HTTPError=HTTPError;req.RequestException=type('RequestException',(Exception,),{})
def forbidden(*args,**kwargs):raise AssertionError('Network forbidden in pure-logic checks')
req.get=req.post=forbidden
sys.modules['requests']=req
suite=unittest.defaultTestLoader.discover(str(Path(__file__).resolve().parent/'app/tests'))
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
