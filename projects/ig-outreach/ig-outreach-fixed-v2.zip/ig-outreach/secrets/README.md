Copy .env.example to .env and fill in your own settings. Restore your Google service-account JSON separately. Never upload this folder to GitHub. AI_MODELS is optional; see DIAGNOSIS.md.
