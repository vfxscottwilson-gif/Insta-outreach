"""Model-agnostic AI client.

You only provide API keys (secret AI_API_KEYS, one per line). For every key this module:
  1. detects the provider (Gemini, Groq, OpenRouter, Mistral, OpenAI, Anthropic),
  2. asks that provider for its CURRENT model list,
  3. picks the newest usable chat models (cheap/free first),
  4. falls back to the next model / next provider automatically on any failure
     (rate limit, credit exhausted, outage, removed model, bad key).
Optional AI_MODELS JSON bypasses discovery with explicit provider model IDs.
"""
import re
import os
import json
import time
import requests

TIMEOUT = 45
SKIP = re.compile(
    r"whisper|guard|tts|audio|embed|moderation|transcri|speech|image|imagen|veo|orpheus|"
    r"playai|ocr|rerank|safety|robotics|aqa|learnlm|dall|sora|realtime|codex|search|computer|"
    r"davinci|babbage|vision-only", re.I)
BASES = {
    "groq": "https://api.groq.com/openai/v1",
    "mistral": "https://api.mistral.ai/v1",
    "openrouter": "https://openrouter.ai/api/v1",
    "openai": "https://api.openai.com/v1",
}
GEMINI = "https://generativelanguage.googleapis.com/v1beta"
ANTHROPIC = "https://api.anthropic.com/v1"


def _zero(value):
    try:
        return float(value) == 0
    except (ValueError, TypeError):
        return False


def safe_error(exc):
    # HTTP exception strings can contain URLs with credentials. Never log them.
    response = getattr(exc, "response", None)
    return f"HTTP {response.status_code}" if response is not None else type(exc).__name__


def _hdr_anthropic(key):
    return {"x-api-key": key, "anthropic-version": "2023-06-01"}


def candidates(provider: str, key: str) -> list:
    """Return model ids for this key, best first."""
    if provider == "gemini":
        r = requests.get(f"{GEMINI}/models?pageSize=200", headers={"x-goog-api-key": key}, timeout=TIMEOUT)
        r.raise_for_status()
        rows = []
        for m in r.json().get("models", []):
            name = m["name"].split("/")[-1]
            if "generateContent" not in m.get("supportedGenerationMethods", []):
                continue
            if SKIP.search(name):
                continue
            nums = re.findall(r"\d+(?:\.\d+)?", name)
            rows.append((float(nums[0]) if nums else 0.0, "lite" not in name,
                         not re.search(r"preview|exp", name), name))
        rows.sort(reverse=True)
        return [r_[3] for r_ in rows]

    if provider == "anthropic":
        r = requests.get(f"{ANTHROPIC}/models?limit=100", headers=_hdr_anthropic(key), timeout=TIMEOUT)
        r.raise_for_status()
        rows = [(("opus" not in m["id"]), m.get("created_at", ""), m["id"]) for m in r.json().get("data", [])]
        rows.sort(reverse=True)
        return [x[2] for x in rows]

    r = requests.get(BASES[provider] + "/models", headers={"Authorization": f"Bearer {key}"}, timeout=TIMEOUT)
    r.raise_for_status()
    rows = []
    for m in r.json().get("data", []):
        mid = m.get("id", "")
        if not mid or SKIP.search(mid):
            continue
        if provider == "openai" and not re.match(r"(gpt|o\d)", mid):
            continue
        if provider == "openrouter":
            pr = m.get("pricing", {})
            if not (_zero(pr.get("prompt")) and _zero(pr.get("completion"))):
                continue  # free models only
            if "text" not in (m.get("architecture", {}).get("output_modalities") or ["text"]):
                continue
        if provider == "mistral" and not m.get("capabilities", {}).get("completion_chat", True):
            continue
        cheap = 1 if (provider == "openai" and "mini" in mid) else 0
        rows.append((cheap, m.get("created") or 0, mid))
    rows.sort(reverse=True)
    return [x[2] for x in rows]


def detect(key: str):
    if key.startswith("sk-ant-"):
        return "anthropic"
    if key.startswith("gsk_"):
        return "groq"
    if key.startswith("sk-or-"):
        return "openrouter"
    if key.startswith("AIza"):
        return "gemini"
    if key.startswith("sk-"):
        return "openai"
    # Opaque keys require an explicit provider prefix; never transmit a key to
    # unrelated services just to guess who issued it.
    return None


class AI:
    def __init__(self, raw_keys: str):
        self.pool = []  # [provider, key, [models], alive]
        self.notes = []
        keys = [k.strip() for k in re.split(r"[\n,; ]+", raw_keys or "") if k.strip()]
        try:
            configured = json.loads(os.getenv("AI_MODELS", "") or "{}")
            if not isinstance(configured, dict):
                raise ValueError()
        except (ValueError, TypeError):
            raise ValueError('AI_MODELS must be a JSON object: {"provider": ["model-id"]}')
        for item in keys:
            explicit, sep, value = item.partition(":")
            k = value if sep and explicit in (*BASES, "gemini", "anthropic") else item
            p = explicit if sep and explicit in (*BASES, "gemini", "anthropic") else detect(k)
            if not p:
                self.notes.append("One key in AI_API_KEYS was not recognised (use provider:key for opaque keys).")
                continue
            try:
                models = configured.get(p) or []
                if isinstance(models, str):
                    models = [models]
                if not isinstance(models, list) or not all(isinstance(m, str) and m.strip() for m in models):
                    raise ValueError("Invalid model list")
                models = list(models) if models else candidates(p, k)
            except Exception as e:
                self.notes.append(f"{p}: could not list models ({safe_error(e)}).")
                continue
            if models:
                self.pool.append([p, k, models, True])
            else:
                self.notes.append(f"{p}: key works but no usable chat models found.")
        if not self.pool:
            raise RuntimeError("No working AI key. " + " ".join(self.notes))

    def _call(self, provider, key, model, prompt, max_tokens):
        if provider == "gemini":
            r = requests.post(
                f"{GEMINI}/models/{model}:generateContent", headers={"x-goog-api-key": key},
                json={"contents": [{"parts": [{"text": prompt}]}],
                      "generationConfig": {"temperature": 0.9, "maxOutputTokens": max(max_tokens, 2048)}},
                timeout=TIMEOUT)
            r.raise_for_status()
            parts = r.json()["candidates"][0]["content"]["parts"]
            text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        elif provider == "anthropic":
            r = requests.post(f"{ANTHROPIC}/messages", headers=_hdr_anthropic(key),
                              json={"model": model, "max_tokens": max(max_tokens, 600), "temperature": 0.9,
                                    "messages": [{"role": "user", "content": prompt}]}, timeout=TIMEOUT)
            r.raise_for_status()
            text = "".join(b.get("text", "") for b in r.json().get("content", []))
        else:
            body = {"model": model, "messages": [{"role": "user", "content": prompt}]}
            if provider == "openai":  # newer OpenAI models reject max_tokens/temperature
                body["max_completion_tokens"] = max(max_tokens, 2000)
            else:
                body.update({"temperature": 0.9, "max_tokens": max(max_tokens, 600)})
            r = requests.post(BASES[provider] + "/chat/completions",
                              headers={"Authorization": f"Bearer {key}"}, json=body, timeout=TIMEOUT)
            r.raise_for_status()
            text = r.json()["choices"][0]["message"]["content"] or ""
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
        if not text:
            raise ValueError("empty reply")
        return text

    def generate(self, prompt: str, max_tokens: int = 300) -> str:
        last = None
        for attempt in range(3):  # later rounds come after a pause (rate limits)
            for entry in self.pool:
                provider, key, models, alive = entry
                if not alive:
                    continue
                for model in list(models[:5]):
                    try:
                        text = self._call(provider, key, model, prompt, max_tokens)
                        models.remove(model)
                        models.insert(0, model)  # remember the one that works
                        return text
                    except requests.HTTPError as e:
                        last = e
                        code = e.response.status_code if e.response is not None else 0
                        if code == 401:      # bad/expired key or no credit: stop using this key today
                            entry[3] = False
                            self.notes.append(f"{provider} key rejected ({code}); skipped for this run.")
                            break
                        if code == 402:             # out of credit
                            entry[3] = False
                            self.notes.append(f"{provider} out of credit; switched provider.")
                            break
                        if code == 429:             # rate limit: go to the next provider, retry later
                            break
                        if code in (400, 403, 404, 410) and model in models:
                            models.remove(model)
                        time.sleep(1)
                    except Exception as e:
                        last = e
                        time.sleep(1)
            if not any(e[3] for e in self.pool):
                break
            if attempt < 2:
                time.sleep(20 * (attempt + 1))
        raise RuntimeError(f"All AI providers failed: {safe_error(last)}")
