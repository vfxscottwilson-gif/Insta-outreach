# Instagram Outreach v3 (ig-outreach)

## Purpose
Reads leads from a Google Sheet, writes short personalised Instagram DMs (under 40 words, 9 rotating angles, free-sample offer) and schedules them across accounts with follow-ups. A human sends each DM (`send_assist.py` is one-click, not an auto-sender). Goal: booked calls for the agency.

## How to run
- GitHub Actions: workflow "Daily outreach prep" (`.github/workflows/outreach.yml`): cron `0 12 * * *` UTC full run, `0 */4 * * *` sync-only, plus manual `workflow_dispatch` (input `sync_only`).
- Local: `python main.py` (full) or `python main.py --sync-only`.
- Sending helper on your PC: `python send_assist.py [acc1 acc2]` (needs `profiles.json` copied from `profiles.example.json`).
- Setup: `pip install -r requirements.txt`; details in `SETUP_GUIDE.md`.

## Secrets needed (names only)
- Required secrets: `GOOGLE_SERVICE_ACCOUNT_JSON`, `AI_API_KEYS` (one key per line, at least 2 providers).
- Optional: `IG_ACCESS_TOKEN` (profile reading; without it the bot falls back to sheet Niche/Bio).
- Variables: `SHEET_ID` (required); optional or defaulted: `AGENT_ACCOUNTS`, `AGENCY_NAME`, `SENDER_NAME`, `OFFER`, `FREE_SAMPLE`, `CASE_STUDIES`, `DAILY_LIMIT_PER_ACCOUNT`, `SEND_WINDOW`, `MSG_GAP_MINUTES`, `FOLLOWUP_GAPS`, `TIMEZONE`, `DATE_FORMAT`, `LEADS_TAB`, `IG_USER_ID`.

## Key files
- `main.py`: pipeline (sync, expire stale, follow-ups, re-queue, write DMs, fill Today Queue).
- `ai.py`: model-agnostic AI client with provider failover; no hard-coded models.
- `ig.py`: Meta Business Discovery profile reader (optional).
- `rules.py`: message safety checks (length, spam words, links, free-sample mention).
- `styles.py`: the 9 message angles, least-used first.
- `send_assist.py`: local clipboard/Chrome-profile send helper.
- `apps_script.gs`: Sheet script that stamps exact send time.
- `SETUP_GUIDE.md`: setup, safety controls, roadmap.

## Status / known issues
- v3: v2 bugs fixed (daily-limit overrun, lost queue rows, header overwrite, 429 crashes).
- Pending/limits: reply tracking is manual; no unattended sender by design (against Instagram terms); same IP across accounts risks bans; needs real `CASE_STUDIES` for case-study angles; run a 20-lead test before scaling.

## Rules for Claude
- Never commit secrets; do not open .env, Keys or "all info" files.
- Test on 5-10 rows first, with one account.
- Sheet rows are append-only: never delete or rewrite existing log rows; match columns by header name.
- Paid APIs and AI keys stay optional; a missing key must never crash the bot.
- Decision-maker names are facts only, never guessed. No invented stats or fake case studies.
- Keep the daily cap (hard 20, ramp rules); never add auto-login or auto-send.
