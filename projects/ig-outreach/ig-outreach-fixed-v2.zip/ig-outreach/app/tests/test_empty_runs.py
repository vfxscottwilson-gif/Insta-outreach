import contextlib
import io
import os
import unittest
from datetime import timezone
from unittest.mock import MagicMock, patch
import main as M

class EmptyRunTests(unittest.TestCase):
    def test_existing_handles_are_not_new_leads(self):
        fresh, known = M.lead_inventory([{"handle":"alice"},{"handle":"bob"}],{"@Alice"})
        self.assertEqual(fresh,[{"handle":"bob"}])
        self.assertEqual(known,1)

    def test_readback_fails_if_rows_missing(self):
        ws=MagicMock();ws.title="Today Queue"
        with patch.object(M,"get_all",return_value=[["header"]]):
            with self.assertRaisesRegex(RuntimeError,"verification failed"):
                M.verify_rows(ws,[["draft"]],1)

    def test_readback_checks_multiplicity(self):
        ws=MagicMock();ws.title="Today Queue"
        with patch.object(M,"get_all",return_value=[["header"],["draft"]]):
            with self.assertRaises(RuntimeError):
                M.verify_rows(ws,[["draft"],["draft"]],1)

    def test_readback_accepts_actual_rows(self):
        with patch.object(M,"get_all",return_value=[["header"],["draft"]]):
            self.assertEqual(M.verify_rows(None,[["draft",""]],2),1)

    def test_eleven_requeues_zero_new_explained_without_ai(self):
        M.C.clear();M.C.update({h:i for i,h in enumerate(M.LOG_H)})
        M.Q.clear();M.Q.update({h:i for i,h in enumerate(M.Q_H)})
        sh,log_ws,q_ws,acc_ws,run_ws=[MagicMock() for _ in range(5)]
        q_ws.id=123
        log=[M.LOG_H]
        leads=[]
        for i in range(11):
            r=[""]*len(M.LOG_H)
            for h,v in {"Instagram Handle":f"lead{i}","Agent Account":"a","Stage":"Queued","Message Sent":"Existing approved draft"}.items():
                r[M.C[h]]=v
            log.append(r);leads.append({"handle":f"lead{i}"})
        queued=[M.Q_H]
        def append(ws,rows):
            if ws is q_ws:queued.extend(rows)
        output=io.StringIO()
        settings={"GOOGLE_SERVICE_ACCOUNT_JSON":"dummy","SHEET_ID":"dummy","OFFER":"video","AI_API_KEYS":""}
        with patch.dict(os.environ,settings), patch.object(M,"ZoneInfo",return_value=timezone.utc), patch.object(M,"connect",return_value=(sh,log_ws,q_ws,acc_ws,run_ws)), patch.object(M,"sync",return_value=(0,log,[M.Q_H])), patch.object(M,"load_accounts",return_value={"a":20}), patch.object(M,"read_leads",return_value=(leads,1)), patch.object(M,"batch"), patch.object(M,"append",side_effect=append), patch.object(M,"get_all",side_effect=lambda ws:queued if ws is q_ws else log), patch.object(M,"AI",side_effect=AssertionError("AI must not be called")), contextlib.redirect_stdout(output):
            M.main()
        text=output.getvalue()
        self.assertIn("requeued=11",text)
        self.assertIn("new=0",text)
        self.assertIn("already_in_log=11",text)
        self.assertIn("queue_rows_verified=11",text)
        self.assertIn("every valid source handle already exists",text)
        self.assertEqual(len(queued)-1,11)

if __name__ == "__main__":unittest.main()
