import os
import unittest
from datetime import date
from unittest.mock import patch
import main as M
import ai

class RegressionTests(unittest.TestCase):
    def setUp(self):
        M.C.clear(); M.C.update({h:i for i,h in enumerate(M.LOG_H)})
        M.Q.clear(); M.Q.update({h:i for i,h in enumerate(M.Q_H)})

    def test_free_prices_accept_decimal_zero(self):
        self.assertTrue(ai._zero("0.0000"))
        self.assertFalse(ai._zero(None))
        self.assertFalse(ai._zero("0.1"))

    def test_instruction_models_not_filtered(self):
        self.assertIsNone(ai.SKIP.search("llama-3-instruct"))

    def test_explicit_model_skips_discovery(self):
        with patch.dict(os.environ, {"AI_MODELS": '{"groq": ["my-chat-model"]}'}), patch.object(ai, "candidates", side_effect=AssertionError("discovery called")):
            client = ai.AI("groq:opaque-key")
            self.assertEqual(client.pool[0][2], ["my-chat-model"])

    def test_warmup_override_cannot_bypass(self):
        self.assertEqual(M.account_cap(["a","2026-11-09","Active","","20"],date(2026,11,10),10)[0],0)
        self.assertEqual(M.account_cap(["a","2026-10-20","Active","","20"],date(2026,11,10),10)[0],5)

    def test_reordered_accounts(self):
        headers=list(reversed(M.ACC_H))
        M.A.clear(); M.A.update({h:i for i,h in enumerate(headers)})
        canonical=["acc1","2020-01-01","Active","","","",""]
        row=[dict(zip(M.ACC_H,canonical))[h] for h in headers]
        updates=[]
        with patch.object(M,"get_all",return_value=[headers,row]), patch.object(M,"batch",side_effect=lambda ws,data:updates.extend(data)):
            self.assertEqual(M.load_accounts(None,[],date(2026,11,10),10),{"acc1":10})
        self.assertEqual(updates[0]["range"],"B2")

    def test_invalid_queue_type_stays_unsynced(self):
        from datetime import timezone
        log=[M.LOG_H,[""]*len(M.LOG_H)]
        log[1][M.C["Instagram Handle"]]="example"
        q=[""]*len(M.Q_H)
        for key,value in {"Instagram Handle":"example","Done? (type Yes)":"Yes","Type":"Follow-up 9"}.items():
            q[M.Q[key]]=value
        batches=[]
        with patch.object(M,"get_all",side_effect=[log,[M.Q_H,q]]), patch.object(M,"batch",side_effect=lambda ws,data:batches.extend(data)):
            result=M.sync(None,None,date(2026,11,10),timezone.utc,[4,4,4])
        self.assertEqual(result[0],0)
        self.assertEqual(batches,[])

    def test_orphan_queue_stays_unsynced(self):
        from datetime import timezone
        q=[""]*len(M.Q_H)
        q[M.Q["Instagram Handle"]]="missing"
        q[M.Q["Done? (type Yes)"]]="Yes"
        batches=[]
        with patch.object(M,"get_all",side_effect=[[M.LOG_H],[M.Q_H,q]]), patch.object(M,"batch",side_effect=lambda ws,data:batches.extend(data)):
            M.sync(None,None,date(2026,11,10),timezone.utc,[4,4,4])
        self.assertEqual(batches,[])

    def test_invalid_window_has_actionable_error(self):
        from datetime import timezone
        with patch.dict(os.environ,{"SEND_WINDOW":"25:00-26:00"}):
            with self.assertRaisesRegex(ValueError,"SEND_WINDOW"):
                M.send_window(timezone.utc,date(2026,11,10))

    def test_errors_do_not_expose_urls(self):
        import requests
        e=requests.HTTPError("secret in URL")
        self.assertNotIn("secret",ai.safe_error(e))

if __name__ == "__main__":
    unittest.main()
