"""Fact-cleaning helpers (v6). Every library here is optional: if one is missing the plain behaviour is used, never a crash.

- Phones: written WITHOUT a leading '+' (a '+' or '=' at the start of a cell can be read as a formula by Sheets/Excel).
- Links: tracking parameters removed; link-in-bio hosts (linktr.ee ...) are never a Website.
- Structured data: JSON-LD / microdata the business published itself (sameAs, email, telephone), via extruct.
- Duplicates: same phone digits, or same registered domain + near-identical name (RapidFuzz).
"""
import json
import re
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

try:
    import phonenumbers
except ImportError:                                             # pragma: no cover
    phonenumbers = None
try:
    from rapidfuzz import fuzz
except ImportError:                                             # pragma: no cover
    fuzz = None
try:
    import tldextract
    _TLD = tldextract.TLDExtract(suffix_list_urls=())           # bundled snapshot: no network call
except Exception:                                               # pragma: no cover
    _TLD = None
try:
    import extruct
except ImportError:                                             # pragma: no cover
    extruct = None
try:
    from email_validator import EmailNotValidError, validate_email
except ImportError:                                             # pragma: no cover
    validate_email = None

TRACKING = re.compile(r"^(utm_.*|fbclid|gclid|igshid|igsh|mc_cid|mc_eid|ref|ref_src|si|feature)$", re.I)
SOCIAL_HOSTS = {"instagram.com": "Instagram", "facebook.com": "Facebook", "linkedin.com": "LinkedIn",
                "tiktok.com": "TikTok", "youtube.com": "YouTube", "x.com": "Twitter / X", "twitter.com": "Twitter / X"}


def digits(s):
    return re.sub(r"\D", "", s or "")


def clean_phone(raw, region=""):
    """'+1 (415) 555-2671' -> '(415) 555-2671' for a US lead; a foreign number keeps its country code but no '+'.
    Returns '' for something that cannot be a phone number."""
    raw = (raw or "").strip()
    if not raw:
        return ""
    if phonenumbers is not None:
        try:
            n = phonenumbers.parse(raw, (region or "").upper() or None)
            if not phonenumbers.is_possible_number(n):
                return ""
            if region and phonenumbers.region_code_for_number(n) == region.upper():
                return phonenumbers.format_number(n, phonenumbers.PhoneNumberFormat.NATIONAL)
            return phonenumbers.format_number(n, phonenumbers.PhoneNumberFormat.INTERNATIONAL).lstrip("+")
        except Exception:
            pass
    out = re.sub(r"[^\d ()\-.]", "", raw.replace("+", " ")).strip()
    return out if 7 <= len(digits(out)) <= 15 else ""


def clean_url(u):
    """Drop tracking parameters and fragments; force https:// when the scheme is missing."""
    u = (u or "").strip()
    if not u:
        return ""
    if not u.startswith(("http://", "https://")):
        u = "https://" + u
    p = urlparse(u)
    q = urlencode([(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if not TRACKING.match(k)])
    return urlunparse((p.scheme, p.netloc, p.path.rstrip("/") if p.path != "/" else "", "", q, ""))


def site_root(u):
    """Website cell: the site's front door (https://host), not a /contact or /pages/... deep link."""
    u = clean_url(u)
    p = urlparse(u)
    return f"{p.scheme}://{p.netloc}/" if p.netloc else ""


def reg_domain(host_or_url):
    """Registered domain: 'shop.example.co.uk' -> 'example.co.uk'."""
    h = (urlparse(host_or_url if "://" in host_or_url else "//" + host_or_url).hostname or "").lower()
    if _TLD is not None:
        ex = _TLD(h)
        if ex.domain and ex.suffix:
            return f"{ex.domain}.{ex.suffix}"
    return h[4:] if h.startswith("www.") else h


def email_ok(e):
    """Syntax check only (the bot's own MX / verifier steps handle deliverability). A '+tag' mailbox is not a real inbox."""
    local = (e or "").partition("@")[0]
    if not e or "+" in local:
        return False
    if validate_email is None:
        return True
    try:
        validate_email(e, check_deliverability=False)
        return True
    except EmailNotValidError:
        return False


def jsonld_facts(html, url=""):
    """Contact facts the site published as structured data. Returns {'emails': [], 'phones': [], 'socials': {plat: url}}."""
    out = {"emails": [], "phones": [], "socials": {}}
    if extruct is None or not html:
        return out
    try:
        data = extruct.extract(html, base_url=url or None, syntaxes=["json-ld", "microdata"], uniform=True)
    except Exception:
        return out
    stack = list(data.get("json-ld", [])) + list(data.get("microdata", []))
    seen = 0
    while stack and seen < 400:
        node = stack.pop()
        seen += 1
        if isinstance(node, list):
            stack.extend(node)
            continue
        if not isinstance(node, dict):
            continue
        for k, v in node.items():
            kl = k.lower()
            vals = v if isinstance(v, list) else [v]
            if kl == "email":
                out["emails"] += [str(x).replace("mailto:", "").strip().lower() for x in vals if isinstance(x, str)]
            elif kl == "telephone":
                out["phones"] += [str(x) for x in vals if isinstance(x, (str, int))]
            elif kl == "sameas":
                for x in vals:
                    if isinstance(x, str):
                        h = (urlparse(x).hostname or "").lower().removeprefix("www.")
                        plat = next((p for d, p in SOCIAL_HOSTS.items() if h == d or h.endswith("." + d)), "")
                        if plat:
                            out["socials"].setdefault(plat, x)
            if isinstance(v, (dict, list)):
                stack.append(v)
    out["emails"] = [e for e in dict.fromkeys(out["emails"]) if email_ok(e)]
    return out


def facebook_facts(html):
    """Public facts on a Facebook page's HTML: email, phone, and the website it links to (l.facebook.com redirect decoded).
    Only what the page itself prints. Returns {'emails': [], 'phones': [], 'website': ''}."""
    out = {"emails": [], "phones": [], "website": ""}
    if not html:
        return out
    h = html.replace("\\/", "/").replace("&amp;", "&")
    for m in re.finditer(r'"(?:email|emails?_address)"\s*:\s*"([^"]+@[^"]+)"', h):
        out["emails"].append(m.group(1).lower())
    out["emails"] += [e.lower() for e in re.findall(r"mailto:([^\"'?\s<>]+@[^\"'?\s<>]+)", h)]
    out["emails"] = [e for e in dict.fromkeys(out["emails"]) if email_ok(e)]
    out["phones"] = list(dict.fromkeys(re.findall(r'"(?:phone|phone_number|telephone)"\s*:\s*"([+\d][\d ()\-.]{6,20})"', h)))[:2]
    for m in re.finditer(r'(?:"website"\s*:\s*"|l\.facebook\.com/l\.php\?u=)(https?(?::|%3A)(?://|%2F%2F)[^"&\s<>]+)', h):
        from urllib.parse import unquote
        u = unquote(m.group(1))
        host = (urlparse(u).hostname or "").lower()
        if host and "facebook.com" not in host and "fb.me" not in host:
            out["website"] = clean_url(u)
            break
    return out


def is_duplicate(lead, earlier):
    """lead/earlier: dicts with Phone, Company Name, Website. Duplicate = same phone digits (>=7), or same registered domain
    and a near-identical name. Chains with different phones and different names stay separate."""
    ph, dom, nm = digits(lead.get("Phone")), reg_domain(lead.get("Website") or ""), (lead.get("Company Name") or "").lower()
    for o in earlier:
        if ph and len(ph) >= 7 and ph == digits(o.get("Phone")):
            return True
        if dom and dom == reg_domain(o.get("Website") or "") and fuzz is not None \
                and fuzz.token_set_ratio(nm, (o.get("Company Name") or "").lower()) >= 94:
            return True
    return False


def benchmark_check(rev_band, rev_floor_ok, posts30, min_posts, pref_posts, emailed, has_dm, has_site, has_phone):
    """One-line checklist for the sheet. ✓ = met by a fact, ✗ = fact says no, ? = not verifiable from public data."""
    def mark(ok):
        return "✓" if ok is True else "✗" if ok is False else "?"
    act = None if posts30 in (None, "") else (posts30 >= min_posts)
    pref = None if posts30 in (None, "") else (posts30 >= pref_posts)
    parts = [f"{mark(rev_floor_ok)} Can afford 500/mo ({rev_band or 'n/a'})",
             f"{mark(act)} Posted in last 30d" + (f" ({posts30})" if posts30 not in (None, "") else ""),
             f"{mark(pref)} Active {pref_posts:g}+ posts/30d",
             f"{mark(emailed)} Email", f"{mark(has_dm)} Decision maker", f"{mark(has_site)} Website", f"{mark(has_phone)} Phone"]
    return "  ".join(parts)


if __name__ == "__main__":                                      # self-check: python src/clean.py
    assert not clean_phone("+1 (415) 555-2671", "US").startswith("+")
    assert clean_phone("+44 20 7946 0958", "US").startswith("44")
    assert clean_phone("abc", "US") == ""
    assert clean_url("Example.com/?utm_source=x&a=1#top") == "https://Example.com?a=1"
    assert not email_ok("a+1@x.com") and email_ok("a@x.com")
    assert is_duplicate({"Phone": "(415) 555-2671"}, [{"Phone": "415-555-2671"}])
    print("clean.py OK")
