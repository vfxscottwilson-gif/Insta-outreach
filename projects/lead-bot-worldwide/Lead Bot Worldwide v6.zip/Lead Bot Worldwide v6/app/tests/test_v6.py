"""v6: benchmarks, clean phones/links, structured data, Facebook facts, duplicates, retry."""
import os
import sys
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import clean as CL        # noqa: E402
import enrich as E        # noqa: E402
import quality as Q       # noqa: E402


class _S:
    def __init__(self, **kw):
        self.kw = kw

    def num(self, k, d=0):
        return self.kw.get(k, d)


class TestPhones(unittest.TestCase):
    def test_no_plus_anywhere(self):
        for raw, region in (("+1 (415) 555-2671", "US"), ("+44 20 7946 0958", "GB"), ("+61 2 9374 4000", "US"),
                            ("+971 4 123 4567", "AE")):
            out = CL.clean_phone(raw, region)
            self.assertTrue(out and not out.startswith(("+", "=", "-")), (raw, out))

    def test_national_for_own_country(self):
        self.assertEqual(CL.clean_phone("+1 415 555 2671", "US"), "(415) 555-2671")

    def test_garbage_dropped(self):
        self.assertEqual(CL.clean_phone("call us", "US"), "")


class TestLinks(unittest.TestCase):
    def test_tracking_removed(self):
        self.assertEqual(CL.clean_url("https://a.com/x?utm_source=ig&id=3&fbclid=z#t"), "https://a.com/x?id=3")

    def test_registered_domain(self):
        self.assertEqual(CL.reg_domain("https://shop.example.co.uk/a"), "example.co.uk")

    def test_plus_tag_email_rejected(self):
        self.assertFalse(CL.email_ok("owner+1@shop.com"))
        self.assertTrue(CL.email_ok("owner@shop.com"))


class TestStructuredData(unittest.TestCase):
    def test_jsonld(self):
        html = ('<script type="application/ld+json">{"@context":"https://schema.org","@type":"Dentist","email":"mailto:Hi@Smile.com",'
                '"telephone":"+1 415 555 2671","sameAs":["https://www.facebook.com/smile","https://www.instagram.com/smile",'
                '"https://linktr.ee/smile"]}</script>')
        f = CL.jsonld_facts(html, "https://smile.com")
        self.assertEqual(f["emails"], ["hi@smile.com"])
        self.assertEqual(f["socials"]["Facebook"], "https://www.facebook.com/smile")
        self.assertNotIn("linktr", str(f["socials"]))
        self.assertTrue(f["phones"])

    def test_facebook_facts(self):
        html = ('{"email":"hello@smile.com","phone":"+1 415 555 2671"} '
                '<a href="https://l.facebook.com/l.php?u=https%3A%2F%2Fsmile.com%2F%3Futm_source%3Dfb">site</a>')
        f = CL.facebook_facts(html)
        self.assertEqual(f["emails"], ["hello@smile.com"])
        self.assertEqual(f["website"], "https://smile.com")
        self.assertTrue(f["phones"])


class TestDuplicates(unittest.TestCase):
    def test_same_phone(self):
        self.assertTrue(CL.is_duplicate({"Phone": "415 555 2671"}, [{"Phone": "(415) 555-2671"}]))

    def test_same_domain_similar_name(self):
        a = {"Company Name": "Smile Dental Clinic", "Website": "https://smile.com", "Phone": "1"}
        b = {"Company Name": "Smile Dental Clinic Ltd", "Website": "https://www.smile.com/about", "Phone": "2"}
        self.assertTrue(CL.is_duplicate(a, [b]))

    def test_chain_branches_kept(self):
        a = {"Company Name": "Gym Downtown", "Website": "https://gym.com", "Phone": "(415) 555-1111"}
        b = {"Company Name": "Gym Uptown Branch", "Website": "https://gym.com", "Phone": "(415) 555-2222"}
        self.assertFalse(CL.is_duplicate(a, [b]))


class TestBenchmark(unittest.TestCase):
    def test_revenue_floor(self):
        S = _S(REV_BAND_MID=15000, REV_BAND_HIGH=60000, MIN_MONTHLY_REVENUE=10000)
        f = {"velocity": 3.0, "reviews": 50}
        q = {"ticket": 20, "visits": 1, "rate": 0.03}          # 3 / 0.03 * 20 = 2,000 per month
        self.assertEqual(Q.revenue_band(f, q, 5, 0.5, S)[0], "Below Floor")
        q = {"ticket": 400, "visits": 1, "rate": 0.03}         # 40,000 per month
        self.assertEqual(Q.revenue_band(f, q, 5, 0.5, S)[0], "Mid")

    def test_checklist_marks(self):
        s = CL.benchmark_check("Mid", True, 6, 1, 4, True, False, True, True)
        self.assertIn("✓ Posted in last 30d (6)", s)
        self.assertIn("✗ Decision maker", s)
        s = CL.benchmark_check("unverified", None, None, 1, 4, True, True, True, True)
        self.assertIn("? Can afford", s)
        self.assertIn("? Posted", s)


class TestRetry(unittest.TestCase):
    def test_busy_then_ok(self):
        calls = {"n": 0}

        class R:
            def __init__(self, code):
                self.status_code, self.headers, self.encoding = code, {"content-type": "text/html"}, "utf-8"

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def iter_content(self, n):
                yield b"<p>ok</p>"

        def fake_get(*a, **k):
            calls["n"] += 1
            return R(429 if calls["n"] == 1 else 200)

        with mock.patch.object(E, "allowed", return_value=True), mock.patch.object(E.requests, "get", fake_get), \
                mock.patch("time.sleep"), mock.patch("tenacity.nap.time.sleep"):
            self.assertIn("ok", E.fetch("https://x.com") or "")
        self.assertEqual(calls["n"], 2)


if __name__ == "__main__":
    unittest.main()
