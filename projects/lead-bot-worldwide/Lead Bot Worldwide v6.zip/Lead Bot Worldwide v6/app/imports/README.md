# imports/ — scraper exports the bot reads every run

Drop `.csv`, `.tsv`, `.json`, `.jsonl` files here (or paste the same rows, header included, into the sheet's **Import** tab).
Every row goes through the normal pipeline: dedupe (Seen tab) → website read → enrich → ICP score → only ≥ 7/10 is written.

Supported out of the box:
- **gosom/google-maps-scraper** CSV (`-results x.csv`) and `-json` output: title, category, address, website/web_site, phone,
  review_count, review_rating, place_id, cid, status, price_range, complete_address, emails …
- **yt-dlp wrapper** CSV (`yt_leads.ps1`): title, website, email, subscribers, channel_id, latest_video, description.
- Anything else with recognisable headers (name / business name, site / url, phone number, rating / stars, reviews, email, city, country …).

Niche per row: a `niche` column, or the file name `Niche Name__anything.csv`
(e.g. `Real Estate Agencies (Independent)__leeds.csv`), or the `category` matched to the Niches tab search terms,
else `IMPORT_DEFAULT_NICHE`.

**PUBLIC repo warning:** files in this folder are public on GitHub. For a public repo use the sheet's **Import** tab instead.
Rows already processed are skipped instantly next run (Seen tab), so you can leave files here.
