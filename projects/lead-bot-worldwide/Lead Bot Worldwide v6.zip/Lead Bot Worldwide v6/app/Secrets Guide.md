# SECRETS_GUIDE: one GitHub secret per key

**Where to add them:** GitHub repo → **Settings → Secrets and variables → Actions**.
- **Secrets** tab → **New repository secret**: keys and ids (hidden in logs).
- **Variables** tab: plain settings.

**Rules (v5):**
- **One key per secret, named exactly as below.** Never put several keys in one secret. The old combined
  `AI_API_KEYS` / `PLACES_API_KEYS` / `YOUTUBE_API_KEYS` still work as a fallback, but a typo in a combined secret is
  how keys went "unregistered" before.
- **Paste the value only.** The bot trims spaces, line breaks and surrounding quotes. For a sheet id you may paste the
  whole sheet URL; the id is cut out of it.
- **Every value gets a shape check.** At startup the log shows a **registration report**, masked to the last 4
  characters, for example:
  ```
  registered: GEMINI_API_KEY_2 (...abcd)
  ignored: GROQ_API_KEY contains spaces or line breaks (paste ONE key per secret)
  ```
  The same line appears in every sheet's **Stats** tab ("Keys registered") and in the Master Dashboard. An ignored
  value is never sent to the service.
- **If a provider changes its key format** and a good key shows "ignored: bad format", set the **Variable**
  `KEY_CHECK` = `warn`. The bot then keeps the key and logs "format unchecked".
- **Nothing is required except `GOOGLE_SA` + at least one sheet id.** Every other key is optional, and a missing key
  switches that module off with no errors.
- **Options tab:** most keys can also be typed into each sheet's **Options** tab. A GitHub secret always wins over the
  Options tab.

## Required

| Secret | Type | Required? | Format (fake example) | Where to get it | Free limit | Unlocks |
|---|---|---|---|---|---|---|
| `GOOGLE_SA` | Secret | **required** | the whole service-account JSON file: `{"type":"service_account","client_email":"bot@proj.iam.gserviceaccount.com","private_key":"-----BEGIN PRIVATE KEY-----\n…"}` | console.cloud.google.com → IAM & Admin → Service Accounts → Keys → Add key (JSON) | free | writing the sheets |
| `SHEET_ID_US` | Secret | required for US (and the Master Dashboard) | `1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789abcdEF` | sheet URL, between `/d/` and `/edit` | free | US sheet; tab 1 = Master Dashboard |
| `SHEET_ID_CA` | Secret | optional | same shape | same | free | Canada sheet |
| `SHEET_ID_GB` (alias `SHEET_ID_UK`) | Secret | optional | same shape | same | free | UK sheet |
| `SHEET_ID_AU` | Secret | optional | same shape | same | free | Australia sheet (worldwide edition) |
| `SHEET_ID_NZ` | Secret | optional | same shape | same | free | New Zealand sheet |
| `SHEET_ID_IE` | Secret | optional | same shape | same | free | Ireland sheet |
| `SHEET_ID_AE` | Secret | optional (Gulf) | same shape | same | free | UAE sheet |
| `SHEET_ID_SA` | Secret | optional (Gulf) | same shape | same | free | Saudi Arabia sheet |
| `SHEET_ID_QA` | Secret | optional (Gulf) | same shape | same | free | Qatar sheet |
| `SHEET_ID_YOUTUBE` (alias `SHEET_ID_YT`) | Secret | optional | same shape | same | free | YouTube creators sheet (worldwide) |
| `SHEET_ID_AU_ONLY` | Secret | **AU-only edition** | same shape | same | free | the Australia-only edition's single sheet |
| `SHEET_ID` | Secret | old single-sheet layout | same shape | same | free | used only when no `SHEET_ID_*` exists |

## AI (Lead Insight only; optional)

The lead bot makes **one small AI call per qualified lead** (3-4 lines in `Lead Insight`), and never writes emails.
- **Key order:** keys are tried in this order: Gemini 1 → 2 → 3 → Groq → others. A key that answers 429 (quota) is
  switched off for the rest of the run, with no waiting and no retries.
- **When every key is off:** the remaining leads get a fact-only insight, and the row's `Enrichment` column says why.

| Secret | Type | Format (fake) | Where | Free limit (check the console; tiers change) | Unlocks |
|---|---|---|---|---|---|
| `GEMINI_API_KEY_1` | Secret | `AIzaSyA1b2C3d4E5f6G7h8I9j0KlMnOpQrStUvW` (AIza + 35) | aistudio.google.com/apikey | Flash models free, about 1,000+ requests/day per project | Lead Insight + decision-maker check |
| `GEMINI_API_KEY_2`, `GEMINI_API_KEY_3` | Secret | same | same, from **another Google account/project** (the quota is per project) | same | more daily quota |
| `GROQ_API_KEY` | Secret | `gsk_` + 52 letters/digits | console.groq.com/keys | about 30 requests/min; daily cap per model | fallback |
| `OPENROUTER_API_KEY` | Secret | `sk-or-v1-` + 64 hex | openrouter.ai/keys | `:free` models, small daily cap | fallback |
| `MISTRAL_API_KEY` | Secret | 32 letters/digits | console.mistral.ai | free "Experiment" tier, low rate | fallback |
| `CEREBRAS_API_KEY` | Secret | `csk-` + letters/digits | cloud.cerebras.ai | free tier (limits vary) | fallback |
| `AI_API_KEYS` | Secret | OLD: several keys, one per line | – | – | fallback only |

## Data sources and enrichment (optional)

| Secret | Type | Format (fake) | Where | Free limit | Unlocks |
|---|---|---|---|---|---|
| `GOOGLE_PLACES_API_KEY` (or `_1`, `_2`) | Secret | `AIza` + 35 | Cloud Console → Places API (New) → Credentials | needs billing; Text Search Enterprise: 1,000 requests/month free, then US$35 per 1,000. The bot caps itself at `PLACES_MAX_REQUESTS_PER_MONTH` (950). Also set a daily quota of 32. | Google rating + reviews → PRIME possible |
| `YOUTUBE_API_KEY_1`, `YOUTUBE_API_KEY_2` | Secret | `AIza` + 35 | Cloud Console → YouTube Data API v3 | 10,000 units/day per project (about 80 searches) | faster YouTube discovery (the no-key reader works without it) |
| `SERPER_API_KEY` | Secret | 40 hex `0123abcd…` | serper.dev | 2,500 free queries once, no card | Google rating + review count for free-map leads, missing websites, LinkedIn owner names |
| `BRAVE_API_KEY` | Secret | `BSA` + about 28 characters | brave.com/search/api | monthly free credit (about 1,000 searches) | backup web search |
| `ZENROWS_API_KEY` | Secret | 40 hex | zenrows.com | 5,000 credits/month | reads sites that block normal readers |
| `JINA_API_KEY` | Secret | `jina_` + letters/digits | jina.ai/reader | works without a key; a key raises the rate limit | JavaScript-heavy sites |
| `HUNTER_API_KEY` | Secret | 40 hex | hunter.io | 25 searches + 50 verifications / month | owner names + personal emails by domain |
| `ZEROBOUNCE_API_KEY` | Secret | 32 hex | zerobounce.net | 100 verifications / month | email verification |
| `APOLLO_API_KEY` | Secret | about 22 characters | apollo.io | free plan, limited API | staff count → revenue score |
| `APIFY_API_TOKEN` | Secret | `apify_api_` + 36 | apify.com → Settings → Integrations | US$5 credit / month | Instagram stats fallback, Google Maps discovery (`USE_APIFY_MAPS`) |
| `IG_ACCESS_TOKEN` | Secret | `EAA…` (long) | developers.facebook.com (Instagram Graph API) | free, about 200 calls/hour | Instagram followers/posts → social score + agency detection |
| `IG_USER_ID` | **Variable** | digits `17841400000000000` | same | – | needed with `IG_ACCESS_TOKEN` |
| `NZBN_API_KEY` | Secret | 32 letters/digits (subscription key) | api.business.govt.nz → subscribe to the NZBN API | free key: check vendor page | NZ: exact registered-name match → directors (decision maker, facts), registry email on their own domain, phone; removed companies skipped |
| `SNOV_CLIENT_ID` + `SNOV_CLIENT_SECRET` | Secret (both) | 32 letters/digits each | snov.io → Settings → API | free credits: check vendor page | personal email of a known decision maker, **only for leads ≥ 7/10** (cap `MAX_SNOV_PER_RUN` 10) |
| `PROSPEO_API_KEY` | Secret | 32 letters/digits | prospeo.io → API | free credits: check vendor page | same as Snov.io, tried first (cap `MAX_PROSPEO_PER_RUN` 10) |
| `REACHER_URL` (+ optional `REACHER_SECRET`) | Secret | `https://reacher.yourvps.com` | self-host check-if-email-exists (Reacher) on a VPS with **port 25 open**: GitHub runners block port 25, so SMTP checks can't run there | open source; your VPS cost | mailbox-level check (safe / risky / invalid) of each email |
| *(no key)* Disify | Rules `USE_DISIFY` = Yes (default **No**) | – | disify.com | free, rate-limited: check vendor page | drops disposable / no-DNS email domains |
| `ABN_GUID` (old name `ABN_LOOKUP_GUID`) | Secret | `1a2b3c4d-1111-2222-3333-444455556666` | abr.business.gov.au → Web services registration | free | AU: entity, GST, business age |

## Variables (not secret)

| Variable | Example | What it does |
|---|---|---|
| `KEY_CHECK` | `warn` | keep keys whose format looks unusual (default: ignore them) |
| `TIMEZONE` | `Australia/Sydney` | dates on the Master Dashboard. Each sheet's Rules tab › `TIMEZONE` sets that sheet's dates. |
| `LEAD_MATRIX` | `{"include":[{"name":"us","country":"US"}]}` | which jobs run (private repo: run fewer) |
| `USE_JINA` | `false` | turn the keyless Jina reader off |

## Checking it worked

Open **Actions → the last run → collect (us) → "Run the bot"**. The first lines are the registration report. Every
key you added should say `registered`. If one says `ignored`, its reason is printed next to it. Re-paste that
secret, with no quotes and no spaces.
